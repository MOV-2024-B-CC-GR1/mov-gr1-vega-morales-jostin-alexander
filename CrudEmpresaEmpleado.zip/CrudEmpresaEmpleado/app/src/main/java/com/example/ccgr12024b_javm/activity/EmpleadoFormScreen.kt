package com.example.ccgr12024b_javm.activity

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.ccgr12024b_javm.model.Empleado
import java.util.*

data class EmpleadoFieldState(
    val value: String = "",
    val error: String? = null
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmpleadoFormScreen(
    empleadoExistente: Empleado?,
    onSave: (Empleado) -> Unit
) {
    var nombre by remember(empleadoExistente) { mutableStateOf(EmpleadoFieldState(empleadoExistente?.nombre ?: "")) }
    var edad by remember(empleadoExistente) { mutableStateOf(EmpleadoFieldState(empleadoExistente?.edad?.toString() ?: "")) }
    var puesto by remember(empleadoExistente) { mutableStateOf(EmpleadoFieldState(empleadoExistente?.puesto ?: "")) }
    var salario by remember(empleadoExistente) { mutableStateOf(EmpleadoFieldState(empleadoExistente?.salario?.toString() ?: "")) }

    // Funciones de validación
    fun validateNombreField(text: String): String? {
        return when {
            text.isBlank() -> "El nombre es requerido"
            text.length < 3 -> "El nombre debe tener al menos 3 caracteres"
            else -> null
        }
    }

    fun validateEdadField(text: String): String? {
        return when {
            text.isBlank() -> "La edad es requerida"
            text.toIntOrNull() == null -> "La edad debe ser un número"
            text.toInt() < 18 -> "La edad debe ser mayor o igual a 18"
            text.toInt() > 100 -> "La edad debe ser menor o igual a 100"
            else -> null
        }
    }

    fun validatePuestoField(text: String): String? {
        return when {
            text.isBlank() -> "El puesto es requerido"
            text.length < 3 -> "El puesto debe tener al menos 3 caracteres"
            else -> null
        }
    }

    fun validateSalarioField(text: String): String? {
        return when {
            text.isBlank() -> "El salario es requerido"
            text.toDoubleOrNull() == null -> "El salario debe ser un número"
            text.toDouble() <= 0 -> "El salario debe ser mayor a 0"
            else -> null
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (empleadoExistente != null) "Editar Empleado" else "Nuevo Empleado") }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = nombre.value,
                onValueChange = {
                    nombre = EmpleadoFieldState(it, validateNombreField(it))
                },
                label = { Text("Nombre") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                isError = nombre.error != null,
                supportingText = { nombre.error?.let { Text(it) } }
            )

            OutlinedTextField(
                value = edad.value,
                onValueChange = { text ->
                    if (text.isEmpty() || text.matches(Regex("^\\d{0,3}$"))) {
                        edad = EmpleadoFieldState(text, validateEdadField(text))
                    }
                },
                label = { Text("Edad") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                isError = edad.error != null,
                supportingText = { edad.error?.let { Text(it) } }
            )

            OutlinedTextField(
                value = puesto.value,
                onValueChange = {
                    puesto = EmpleadoFieldState(it, validatePuestoField(it))
                },
                label = { Text("Puesto") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                isError = puesto.error != null,
                supportingText = { puesto.error?.let { Text(it) } }
            )

            OutlinedTextField(
                value = salario.value,
                onValueChange = { text ->
                    if (text.isEmpty() || text.matches(Regex("^\\d*\\.?\\d*$"))) {
                        salario = EmpleadoFieldState(text, validateSalarioField(text))
                    }
                },
                label = { Text("Salario") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                isError = salario.error != null,
                supportingText = { salario.error?.let { Text(it) } }
            )

            Button(
                onClick = {
                    // Validar todos los campos antes de guardar
                    nombre = nombre.copy(error = validateNombreField(nombre.value))
                    edad = edad.copy(error = validateEdadField(edad.value))
                    puesto = puesto.copy(error = validatePuestoField(puesto.value))
                    salario = salario.copy(error = validateSalarioField(salario.value))

                    // Verificar si hay errores
                    if (listOf(nombre.error, edad.error, puesto.error, salario.error).all { it == null }) {
                        val empleado = Empleado(
                            id = empleadoExistente?.id ?: 0,
                            idEmpresa = empleadoExistente?.idEmpresa ?: 0,
                            nombre = nombre.value,
                            edad = edad.value.toInt(),
                            puesto = puesto.value,
                            fechaContratacion = empleadoExistente?.fechaContratacion ?: Date(),
                            salario = salario.value.toDouble()
                        )
                        onSave(empleado)
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = nombre.value.isNotBlank() && edad.value.isNotBlank() &&
                        puesto.value.isNotBlank() && salario.value.isNotBlank()
            ) {
                Text(if (empleadoExistente != null) "Actualizar" else "Guardar")
            }
        }
    }
}