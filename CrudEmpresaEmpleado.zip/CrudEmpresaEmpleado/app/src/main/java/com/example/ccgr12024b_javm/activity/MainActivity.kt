package com.example.ccgr12024b_javm.activity

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.ccgr12024b_javm.ui.theme.CrudEmpresaEmpleadoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CrudEmpresaEmpleadoTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    MainScreen(
                        onNavigateToEmpresas = {
                            navigateToActivity(EmpresaListActivity::class.java)
                        },
                        onAddEmpresa = {
                            navigateToActivity(EmpresaFormActivity::class.java)
                        },
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }

    /**
     * Función genérica para manejar la navegación a otras actividades.
     */
    private fun navigateToActivity(activityClass: Class<*>) {
        try {
            val intent = Intent(this, activityClass)
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "Error al intentar abrir la actividad: ${activityClass.simpleName}",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}

@Composable
fun MainScreen(
    onNavigateToEmpresas: () -> Unit,
    onAddEmpresa: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Botón para Ver Empresas
        Button(
            onClick = onNavigateToEmpresas,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Text(text = "Ver Empresas")
        }

        // Botón para Agregar Empresa
        Button(
            onClick = onAddEmpresa,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = "Agregar Empresa")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun MainScreenPreview() {
    CrudEmpresaEmpleadoTheme {
        MainScreen(
            onNavigateToEmpresas = {},
            onAddEmpresa = {}
        )
    }
}
