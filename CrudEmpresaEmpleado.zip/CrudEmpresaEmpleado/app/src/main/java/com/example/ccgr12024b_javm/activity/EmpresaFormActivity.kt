package com.example.ccgr12024b_javm.activity

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ccgr12024b_javm.model.Empresa
import com.example.ccgr12024b_javm.repository.EmpresaRepository
import com.example.ccgr12024b_javm.ui.theme.CrudEmpresaEmpleadoTheme

class EmpresaFormActivity : ComponentActivity() {
    private lateinit var empresaRepository: EmpresaRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        empresaRepository = EmpresaRepository(this)

        val empresaId = intent.getIntExtra("empresaId", -1)

        setContent {
            CrudEmpresaEmpleadoTheme {
                EmpresaFormScreen(
                    empresaId = empresaId,
                    empresaRepository = empresaRepository,
                    onSave = { empresa ->
                        val resultado = if (empresaId > 0) {
                            empresaRepository.actualizarEmpresa(empresa)
                            true
                        } else {
                            empresaRepository.insertarEmpresa(empresa) > 0
                        }

                        if (resultado) {
                            Toast.makeText(
                                this,
                                if (empresaId > 0) "Empresa actualizada con éxito" else "Empresa creada con éxito",
                                Toast.LENGTH_SHORT
                            ).show()
                            finish()
                        } else {
                            Toast.makeText(
                                this,
                                if (empresaId > 0) "Error al actualizar empresa" else "Error al crear empresa",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                )
            }
        }
    }
}