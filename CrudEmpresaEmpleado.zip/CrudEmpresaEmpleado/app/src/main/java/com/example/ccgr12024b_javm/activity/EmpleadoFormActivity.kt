package com.example.ccgr12024b_javm.activity

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import com.example.ccgr12024b_javm.model.Empleado
import com.example.ccgr12024b_javm.repository.EmpleadoRepository
import com.example.ccgr12024b_javm.ui.theme.CrudEmpresaEmpleadoTheme

class EmpleadoFormActivity : ComponentActivity() {
    private lateinit var empleadoRepository: EmpleadoRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        empleadoRepository = EmpleadoRepository(this)

        val empresaId = intent.getIntExtra("empresaId", -1)
        val empleadoId = intent.getIntExtra("empleadoId", -1)

        setContent {
            CrudEmpresaEmpleadoTheme {
                var empleadoExistente by remember { mutableStateOf<Empleado?>(null) }

                // Cargar empleado existente si estamos en modo edición
                LaunchedEffect(Unit) {
                    if (empleadoId != -1) {
                        empleadoRepository.obtenerPorId(empleadoId)?.let { empleado ->
                            empleadoExistente = empleado
                        }
                    }
                }

                EmpleadoFormScreen(
                    empleadoExistente = empleadoExistente,
                    onSave = { empleado ->
                        val empleadoFinal = empleado.copy(
                            idEmpresa = empresaId
                        )

                        val resultado = if (empleadoId != -1) {
                            empleadoRepository.actualizarEmpleado(empleadoFinal)
                        } else {
                            empleadoRepository.insertarEmpleado(empleadoFinal) > 0
                        }

                        if (resultado) {
                            Toast.makeText(
                                this,
                                if (empleadoId != -1) "Empleado actualizado con éxito" else "Empleado guardado con éxito",
                                Toast.LENGTH_SHORT
                            ).show()
                            finish()
                        } else {
                            Toast.makeText(
                                this,
                                if (empleadoId != -1) "Error al actualizar empleado" else "Error al guardar empleado",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                )
            }
        }
    }
}