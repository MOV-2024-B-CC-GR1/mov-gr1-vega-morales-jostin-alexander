package com.example.ccgr12024b_javm.activity

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import com.example.ccgr12024b_javm.model.Empresa
import com.example.ccgr12024b_javm.repository.EmpresaRepository
import com.example.ccgr12024b_javm.ui.theme.CrudEmpresaEmpleadoTheme

class EmpresaListActivity : ComponentActivity() {
    private lateinit var empresaRepository: EmpresaRepository
    private var empresas by mutableStateOf(listOf<Empresa>())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        empresaRepository = EmpresaRepository(this)

        setContent {
            CrudEmpresaEmpleadoTheme {
                EmpresaListScreen(
                    empresas = empresas,
                    onEditEmpresa = { empresa ->
                        val intent = Intent(this, EmpresaFormActivity::class.java).apply {
                            putExtra("empresaId", empresa.id)
                        }
                        startActivity(intent)
                    },
                    onDeleteEmpresa = { empresa ->
                        empresaRepository.eliminarEmpresa(empresa.id)
                        loadEmpresas()
                    },
                    onViewEmpleados = { empresa ->
                        val intent = Intent(this, EmpleadoListActivity::class.java).apply {
                            putExtra("empresaId", empresa.id)
                        }
                        startActivity(intent)
                    },
                    onNavigateBack = {
                        finish() // Regresa a la pantalla principal
                    },
                    onAddEmpresa = {
                        val intent = Intent(this, EmpresaFormActivity::class.java)
                        startActivity(intent)
                    }
                )
            }
        }

        loadEmpresas()
    }

    override fun onResume() {
        super.onResume()
        loadEmpresas()
    }

    private fun loadEmpresas() {
        empresas = empresaRepository.obtenerTodas()
    }
}