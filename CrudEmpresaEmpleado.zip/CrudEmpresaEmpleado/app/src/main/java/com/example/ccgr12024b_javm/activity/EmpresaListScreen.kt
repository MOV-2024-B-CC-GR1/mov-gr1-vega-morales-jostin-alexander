package com.example.ccgr12024b_javm.activity

import androidx.compose.runtime.Composable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ccgr12024b_javm.model.Empresa
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.ArrowBack

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmpresaListScreen(
    empresas: List<Empresa>,
    onEditEmpresa: (Empresa) -> Unit,
    onDeleteEmpresa: (Empresa) -> Unit,
    onViewEmpleados: (Empresa) -> Unit,
    onNavigateBack: () -> Unit,  // Nuevo callback para navegación
    onAddEmpresa: () -> Unit     // Nuevo callback para añadir empresa
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Lista de Empresas") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Regresar")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAddEmpresa) {
                Text("+")
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            items(empresas) { empresa ->
                EmpresaItem(
                    empresa = empresa,
                    onEdit = onEditEmpresa,
                    onDelete = onDeleteEmpresa,
                    onViewEmpleados = onViewEmpleados
                )
            }
        }
    }
}

@Composable
fun EmpresaItem(
    empresa: Empresa,
    onEdit: (Empresa) -> Unit,
    onDelete: (Empresa) -> Unit,
    onViewEmpleados: (Empresa) -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "Nombre: ${empresa.nombre}", style = MaterialTheme.typography.titleMedium)
            Text(text = "Ubicación: ${empresa.ubicacion}", style = MaterialTheme.typography.bodyMedium)
            Text(text = "Ingresos Anuales: $${empresa.ingresosAnuales}", style = MaterialTheme.typography.bodyMedium)

            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = androidx.compose.ui.Alignment.CenterEnd
            ) {
                IconButton(onClick = { showMenu = !showMenu }) {
                    Icon(Icons.Default.MoreVert, contentDescription = "Opciones")
                }

                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Editar") },
                        onClick = {
                            showMenu = false
                            onEdit(empresa)
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Eliminar") },
                        onClick = {
                            showMenu = false
                            onDelete(empresa)
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Ver Empleados") },
                        onClick = {
                            showMenu = false
                            onViewEmpleados(empresa)
                        }
                    )
                }
            }
        }
    }
}