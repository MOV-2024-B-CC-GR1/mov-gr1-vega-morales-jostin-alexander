package com.example.ccgr12024b_javm.activity

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ccgr12024b_javm.model.Empleado
import com.example.ccgr12024b_javm.repository.EmpleadoRepository
import com.example.ccgr12024b_javm.ui.theme.CrudEmpresaEmpleadoTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class EmpleadoListActivity : ComponentActivity() {
    private lateinit var empleadoRepository: EmpleadoRepository
    private var empleados by mutableStateOf(listOf<Empleado>())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        empleadoRepository = EmpleadoRepository(this)

        val empresaId = intent.getIntExtra("empresaId", -1)

        setContent {
            CrudEmpresaEmpleadoTheme {
                EmpleadoListScreen(
                    empleados = empleados,
                    onEditEmpleado = { empleado ->
                        val intent = Intent(this, EmpleadoFormActivity::class.java).apply {
                            putExtra("empleadoId", empleado.id)
                            putExtra("empresaId", empresaId)
                        }
                        startActivity(intent)
                    },
                    onDeleteEmpleado = { empleado ->
                        empleadoRepository.eliminarEmpleado(empleado.id)
                        loadEmpleados(empresaId)
                    },
                    onAddEmpleado = {
                        val intent = Intent(this, EmpleadoFormActivity::class.java).apply {
                            putExtra("empresaId", empresaId)
                        }
                        startActivity(intent)
                    },
                    onNavigateBack = {
                        finish() // Regresa a la pantalla anterior
                    }
                )
            }
        }

        loadEmpleados(empresaId)
    }

    override fun onResume() {
        super.onResume()
        val empresaId = intent.getIntExtra("empresaId", -1)
        loadEmpleados(empresaId)
    }

    private fun loadEmpleados(empresaId: Int) {
        empleados = empleadoRepository.obtenerPorEmpresa(empresaId)
    }
}
