package com.example.ccgr12024b_javm.activity

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.ccgr12024b_javm.model.Empresa
import com.example.ccgr12024b_javm.repository.EmpresaRepository
import java.util.*

data class EmpresaFieldState(
    val value: String = "",
    val error: String? = null
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmpresaFormScreen(
    empresaId: Int,
    empresaRepository: EmpresaRepository,
    onSave: (Empresa) -> Unit
) {
    var nombre by remember { mutableStateOf(EmpresaFieldState()) }
    var ubicacion by remember { mutableStateOf(EmpresaFieldState()) }
    var ingresosAnuales by remember { mutableStateOf(EmpresaFieldState()) }
    var numeroEmpleados by remember { mutableStateOf(EmpresaFieldState()) }

    // Cargar datos existentes si es edición
    LaunchedEffect(empresaId) {
        if (empresaId > 0) {
            empresaRepository.obtenerPorId(empresaId)?.let { empresa ->
                nombre = EmpresaFieldState(empresa.nombre)
                ubicacion = EmpresaFieldState(empresa.ubicacion)
                ingresosAnuales = EmpresaFieldState(empresa.ingresosAnuales.toString())
                numeroEmpleados = EmpresaFieldState(empresa.numeroEmpleados.toString())
            }
        }
    }

    // Funciones de validación
    fun validateNombreField(text: String): String? {
        return when {
            text.isBlank() -> "El nombre es requerido"
            text.length < 3 -> "El nombre debe tener al menos 3 caracteres"
            else -> null
        }
    }

    fun validateUbicacionField(text: String): String? {
        return when {
            text.isBlank() -> "La ubicación es requerida"
            text.length < 3 -> "La ubicación debe tener al menos 3 caracteres"
            else -> null
        }
    }

    fun validateIngresosAnualesField(text: String): String? {
        return when {
            text.isBlank() -> "Los ingresos anuales son requeridos"
            text.toDoubleOrNull() == null -> "Los ingresos anuales deben ser un número"
            text.toDouble() < 0 -> "Los ingresos anuales no pueden ser negativos"
            else -> null
        }
    }

    fun validateNumeroEmpleadosField(text: String): String? {
        return when {
            text.isBlank() -> "El número de empleados es requerido"
            text.toIntOrNull() == null -> "El número de empleados debe ser un número entero"
            text.toInt() < 1 -> "El número de empleados debe ser al menos 1"
            else -> null
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text(if (empresaId > 0) "Editar Empresa" else "Nueva Empresa") })
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = nombre.value,
                onValueChange = {
                    nombre = EmpresaFieldState(it, validateNombreField(it))
                },
                label = { Text("Nombre") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                isError = nombre.error != null,
                supportingText = { nombre.error?.let { Text(it) } }
            )

            OutlinedTextField(
                value = ubicacion.value,
                onValueChange = {
                    ubicacion = EmpresaFieldState(it, validateUbicacionField(it))
                },
                label = { Text("Ubicación") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                isError = ubicacion.error != null,
                supportingText = { ubicacion.error?.let { Text(it) } }
            )

            OutlinedTextField(
                value = ingresosAnuales.value,
                onValueChange = { text ->
                    if (text.isEmpty() || text.matches(Regex("^\\d*\\.?\\d*$"))) {
                        ingresosAnuales = EmpresaFieldState(text, validateIngresosAnualesField(text))
                    }
                },
                label = { Text("Ingresos Anuales") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                isError = ingresosAnuales.error != null,
                supportingText = { ingresosAnuales.error?.let { Text(it) } }
            )

            OutlinedTextField(
                value = numeroEmpleados.value,
                onValueChange = { text ->
                    if (text.isEmpty() || text.matches(Regex("^\\d+$"))) {
                        numeroEmpleados = EmpresaFieldState(text, validateNumeroEmpleadosField(text))
                    }
                },
                label = { Text("Número de Empleados") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                isError = numeroEmpleados.error != null,
                supportingText = { numeroEmpleados.error?.let { Text(it) } }
            )

            Button(
                onClick = {
                    // Validar todos los campos antes de guardar
                    nombre = nombre.copy(error = validateNombreField(nombre.value))
                    ubicacion = ubicacion.copy(error = validateUbicacionField(ubicacion.value))
                    ingresosAnuales = ingresosAnuales.copy(error = validateIngresosAnualesField(ingresosAnuales.value))
                    numeroEmpleados = numeroEmpleados.copy(error = validateNumeroEmpleadosField(numeroEmpleados.value))

                    // Verificar si hay errores
                    if (listOf(nombre.error, ubicacion.error, ingresosAnuales.error, numeroEmpleados.error).all { it == null }) {
                        val empresa = Empresa(
                            id = empresaId,
                            nombre = nombre.value,
                            ubicacion = ubicacion.value,
                            fechaCreacion = Date(),
                            numeroEmpleados = numeroEmpleados.value.toInt(),
                            ingresosAnuales = ingresosAnuales.value.toDouble()
                        )
                        onSave(empresa)
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = nombre.value.isNotBlank() &&
                        ubicacion.value.isNotBlank() &&
                        ingresosAnuales.value.isNotBlank() &&
                        numeroEmpleados.value.isNotBlank()
            ) {
                Text(if (empresaId > 0) "Actualizar" else "Guardar")
            }
        }
    }
}