package com.example.ccgr12024b_javm.activity

import androidx.compose.runtime.Composable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ccgr12024b_javm.model.Empleado
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmpleadoListScreen(
    empleados: List<Empleado>,
    onEditEmpleado: (Empleado) -> Unit,
    onDeleteEmpleado: (Empleado) -> Unit,
    onAddEmpleado: () -> Unit,
    onNavigateBack: () -> Unit  // Nuevo callback para navegación
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Lista de Empleados") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Regresar")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAddEmpleado) {
                Text("+")
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            items(empleados) { empleado ->
                EmpleadoItem(
                    empleado = empleado,
                    onEdit = onEditEmpleado,
                    onDelete = onDeleteEmpleado
                )
            }
        }
    }
}

@Composable
fun EmpleadoItem(
    empleado: Empleado,
    onEdit: (Empleado) -> Unit,
    onDelete: (Empleado) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "Nombre: ${empleado.nombre}", style = MaterialTheme.typography.titleMedium)
            Text(text = "Puesto: ${empleado.puesto}", style = MaterialTheme.typography.bodyMedium)
            Text(text = "Salario: $${empleado.salario}", style = MaterialTheme.typography.bodyMedium)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = { onEdit(empleado) }) {
                    Text("Editar")
                }
                TextButton(onClick = { onDelete(empleado) }) {
                    Text("Eliminar")
                }
            }
        }
    }
}
